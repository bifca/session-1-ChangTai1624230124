<html>

<link href="style2.css" rel="stylesheet" type="text/css"/>

<body>


<?php
include 'config.php';

// Check the connection of the server

   $pkid = $_GET["pkid"];
   $sql = "SELECT * FROM pokemon WHERE pkid = '$pkid'";

    $result = mysqli_query($conn,$sql );
   if (mysqli_num_rows($result) > 0) {
     //get informations from server and define them
     while($row = mysqli_fetch_assoc($result)) {
     $pkid = $row["pkid"];
     $name = $row["name"];
     $introduce = $row["introduce"];
     $pic = $row["pic"];
     }
   }
   ?>
   <!-- send informations into updateinfo.php-->
<form action="updateinfo.php" method="POST">

	<div class="filter">
<center>
<br>
<br>
<br>
<br><br>
<div  align="right" style="width:255px;color:black;  opacity:0.65; ">
	<h2>Editinfo Pokemon</h2>
ID <input type="text" value="<?php echo $pkid;?>" name="pkid">
<br>
<br>
Name <input type="text" value="<?php echo $name;?>" name="name">
<br>
<br>
Introduce <input type="text" value="<?php echo $introduce;?>" name="introduce">
<br>
<br>
Picture <input type="text" value="<?php echo $pic;?>" name="pic">
<br>
<br>
</div>
<br>

<input style="margin-left:90px;color:#FFFFFF;background-color:#333333" class="sign"  align="center" type="submit" value=" Submit "/>
</form>
</center>
</div>
</body>
</html>



	</body>
	</html>
