-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2020-03-01 08:31:46
-- 服务器版本： 10.1.38-MariaDB
-- PHP 版本： 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `pokemon`
--

-- --------------------------------------------------------

--
-- 表的结构 `pokemon`
--

CREATE TABLE `pokemon` (
  `pkid` int(3) NOT NULL,
  `name` varchar(100) NOT NULL,
  `introduce` text NOT NULL,
  `pic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `pokemon`
--

INSERT INTO `pokemon` (`pkid`, `name`, `introduce`, `pic`) VALUES
(1, 'Altaria', 'Altaria dances and wheels through the sky among billowing, cotton-like clouds. By singing melodies in its crystal-clear voice, this Pokemon makes its listeners experience dreamy wonderment.', '/Altaria.png'),
(2, 'Arcanine', 'Arcanine is known for its high speed. It is said to be capable of running over 6,200 miles in a single day and night. The fire that blazes wildly within this Pokemon\'s body is its source of power.', '/Arcanine.png'),
(3, 'Diancie', 'A sudden transformation of Carbink, its pink, glimmering body is said to be the loveliest sight in the whole world.', '/Diancie.png'),
(4, 'Gardevoir', 'Gardevoir has the ability to read the future. If it senses impending danger to its Trainer, this Pokemon is said to unleash its psychokinetic energy at full power.', '/Gardevoir.png'),
(5, 'Lucario', 'By catching the aura emanating from others, it can read their thoughts and movements.', '/Lucario.png'),
(6, 'Whimsicott\r\n', 'They appear along with whirlwinds. They pull pranks, such as moving furniture and leaving balls of cotton in homes.', '/Whimsicott.png');

--
-- 转储表的索引
--

--
-- 表的索引 `pokemon`
--
ALTER TABLE `pokemon`
  ADD PRIMARY KEY (`pkid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
