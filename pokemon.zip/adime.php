<?php
include 'config.php';
?>
<html>

<head>
	<title>PHP File Edit</title>
	<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {background-color: #f2f2f2;}
</style>
</head>
<body>

<nav><a href="index.php">Home</a></nav>

<?php

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM pokemon";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        // output data of each row
        echo "<table><th>ID</th><th>Name</th><th>Introduce</th><th>Picture</th><th>Edit</th>";
         while($row = mysqli_fetch_assoc($result)) {
       echo
			 "<tr>
			 <td> "
			 . $row["pkid"]
			 . "</td><td> "
			 . $row["name"]
			 . "</td><td> "
			 . $row["introduce"]
			 . "</td><td>"
			 .'<img src="http://localhost/pokemon/pic'.$row["pic"].'"width="20%">'
			 ."</td>
			 <td><a href='editinfo.php?pkid=".$row["pkid"]."'>Edit</a></td>
			 </tr>";
         }
        echo "</table>";

    } else {
        echo "0 results";
    }

    mysqli_close($conn);
?>
</body>
</html>
