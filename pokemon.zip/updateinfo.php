<?php

//Get the SQL Server Configuration File
include 'config.php';

if(!$conn){
	die("Connection Failed");

}

//Write a SQL query that updates the database below.
//The SQL will start INSERT INTO...
$sql = "
UPDATE pokemon
SET
  pkid = '".$_POST['pkid']."',
	name = '".$_POST['name']."',
	introduce = '".$_POST['introduce']."',
	pic = '".$_POST['pic']."'

WHERE
	pkid = ".$_POST['pkid']."
	";


//If it is successful it will redirect you to the home page.
if (mysqli_query($conn, $sql)){
header("Location: adime.php");
}
//If it fails, it will tell you it has failed.
else{
	echo "failed".$sql."<br>".mysqli_error($conn);

}
?>
